#ifndef Pins_Arduino_h
#define Pins_Arduino_h

// Официальный инклуд базовых макросов MegaCore
#include "../standard/pins_arduino.h"

// Периферия Olimex AVR-MT128
#define BUTTON_1                    (A0)
#define BUTTON_2                    (A1)
#define BUTTON_3                    (A2)
#define BUTTON_4                    (A3)
#define BUTTON_5                    (A4)

#define RELAY_PIN                   (6)  
#define BUZZER_PIN                  (12) 

#define LCD_RS                      (0)  
#define LCD_E                       (2)  
#define LCD_D4                      (16) 
#define LCD_D5                      (17) 
#define LCD_D6                      (18) 
#define LCD_D7                      (19) 

#endif
